// All Named Import
import * as device from "./mobile.js";
const n = new device.Nokia();
n.VolumnUp();
device.show();
console.log(device.a);
